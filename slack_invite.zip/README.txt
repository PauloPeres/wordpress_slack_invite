=== Plugin Name ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: myog.io
Tags: slack, invite, chat, integration
Requires at least: 3.0.1
Tested up to: 4.9.8
Stable tag: 4.9.8
License: MIT
License URI: https://opensource.org/licenses/MIT

This plugin will provide a short-code [slack_invite_form channels=channel-name] that will create a form, and anyone will be able to receive an Slack Invite.

== Description ==



== Installation ==
1. Upload `myog-slack-guest-invite.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Help us improve on our Bitbucket Page ==

Fell free to help us improve documenation and code
https://bitbucket.org/myowngames/slack-guest-invite/src/master/


== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).
2. This is the second screen shot

== Changelog ==

= 1.0 =
* Working

`<?php code(); // goes in backticks ?>`